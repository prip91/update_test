import os
import urllib.request
import shutil
import zipfile

# Angiv URL'en til Teams-mappen, hvor opdateringen er placeret
teams_folder_url = "https://github.com/prip91/Beregner"

# Angiv stien til den lokale mappe, hvor opdateringen skal gemmes
local_folder_path = r"C:\Python39\Øvelser\Update test"

# Hent opdateringen fra Teams-mappen og gem den lokalt
urllib.request.urlretrieve(teams_folder_url, os.path.join(local_folder_path, "opdatering.zip"))

